package com.simple.example;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;



@Component
public class MockProcessor implements Processor {
	private static final Logger logger = LoggerFactory.getLogger(MockProcessor.class);
	    
	public MockProcessor() {
	}
	
	@Override
	public void process(Exchange exchange) throws Exception {

		  String xmlInput = exchange.getIn().getBody(String.class);
		  exchange.getIn().setHeader("accept", "application/json");
		  logger.info("Received Request <<< " + xmlInput);
		 
	      String response = getInfoSuccessResponse().toString();
	      logger.info("Response Sent >>> " + response);
	      exchange.getOut().setBody(response);
	      exchange.getOut().setHeader(Exchange.CONTENT_TYPE, "application/XML");
	      exchange.getOut().setHeader(Exchange.HTTP_RESPONSE_CODE, 201);
	} 

	 private StringBuilder getInfoSuccessResponse() {
		    
	        String xmlResponse = "	\r\n" + 
	        		"<S:Envelope xmlns:S=\"http://schemas.xmlsoap.org/soap/envelope/\">	\r\n" + 
	        		"   <S:Body>	\r\n" + 
	        		"      <ns3:KCBChannelAccountBalanceResponse xmlns:ns3=\"http://temenos.com/T24BalanceEnquiry\" xmlns:ns2=\"http://temenos.com/KCBCHANNELACCTBAL\">	\r\n" + 
	        		"         <Status>	\r\n" + 
	        		"            <successIndicator>Success</successIndicator>	\r\n" + 
	        		"         </Status>	\r\n" + 
	        		"         <KCBCHANNELACCTBALType>	\r\n" + 
	        		"            <ns2:gKCBCHANNELACCTBALDetailType>	\r\n" + 
	        		"               <ns2:mKCBCHANNELACCTBALDetailType>	\r\n" + 
	        		"                  <ns2:AcctNumber>11111111</ns2:AcctNumber>	\r\n" + 
	        		"                  <ns2:Currency/>	\r\n" + 
	        		"                  <ns2:UnclearedBalance>0.00</ns2:UnclearedBalance>	\r\n" + 
	        		"                  <ns2:AccountBalance>0.00</ns2:AccountBalance>	\r\n" + 
	        		"                  <ns2:LimitAmount>0.00</ns2:LimitAmount>	\r\n" + 
	        		"                  <ns2:InactiveMarker/>	\r\n" + 
	        		"                  <ns2:PostingRestrict/>	\r\n" + 
	        		"                  <ns2:WorkingBalance>0.00</ns2:WorkingBalance>	\r\n" + 
	        		"                  <ns2:LockedAmount>0.00</ns2:LockedAmount>	\r\n" + 
	        		"                  <ns2:MinimumBalance>0.00</ns2:MinimumBalance>	\r\n" + 
	        		"               </ns2:mKCBCHANNELACCTBALDetailType>	\r\n" + 
	        		"            </ns2:gKCBCHANNELACCTBALDetailType>	\r\n" + 
	        		"         </KCBCHANNELACCTBALType>	\r\n" + 
	        		"      </ns3:KCBChannelAccountBalanceResponse>	\r\n" + 
	        		"   </S:Body>	\r\n" + 
	        		"</S:Envelope>	\r\n" + 
	        		"";
	       
	       return new StringBuilder(xmlResponse); 
	    }
	    
}